const express  = require('express');
const router   = express.Router();

let db;

const response = data => ({ message: data });

router.get('/', (req, res) => {
	return db.getPosts()
		.then(allPosts => {
			res.render('index.html', {allPosts});
		})
});

router.get('/posts/:id', (req, res) => {
	if(req.params.id){
		return db.getPost(req.params.id)
			.then(rawData => {
				postData = Object.values(JSON.parse(JSON.stringify(rawData)))
				res.render("post.html", {post: postData[0]})
			})
			.catch(() => res.render("post.html", {error: true}))
	}
	return res.redirect('/');
});


module.exports = database => { 
	db = database;
	return router;
};