#!/bin/bash
docker rm -f web_tour_blog
docker build -t web_tour_blog . && \
docker run --name=web_tour_blog --rm -p1337:1337 -it web_tour_blog