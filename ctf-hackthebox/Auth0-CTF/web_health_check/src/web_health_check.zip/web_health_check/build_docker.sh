#!/bin/bash
docker rm -f web_health_checker
docker build -t web_health_checker . 
docker run --name=web_health_checker --rm -p1337:80 -it web_health_checker
