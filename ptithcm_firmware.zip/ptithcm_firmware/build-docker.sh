#!/bin/bash
docker rm -f ptithcm
docker build --tag=ptithcm .
docker run -p 10337:1337 --rm --name=ptithcm ptithcm